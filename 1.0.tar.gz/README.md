## Summary
A text-based adventure game created by Devin Coles, Aidan Gonzalez, Chelsea Onuska, and Scott Wilder.

## Run Intructions
1. Download the TextAdventure.jar file.
2. Once downloaded, open the console. Find and enter the directory with the .jar file.
3. Type in "java -jar TextAdventure.jar"
4. Press enter and the game will begin to run.

## Directions
The once the text is displayed completely, there will be words that are capatilized. These words are the vaild inputs the user can type in. Once typed in, hit the 'Enter' key in order to input the value. The player will move to the room the corresponds with the input.
