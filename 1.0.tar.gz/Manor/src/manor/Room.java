package manor;

public class Room 
{
    int adjacentRooms[] = {} ;
}
