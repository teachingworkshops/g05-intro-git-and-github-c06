/**
 * 
 */
/**
 * @author onuskac
 *
 */
module TextAdventures {
}